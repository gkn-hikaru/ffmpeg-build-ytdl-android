/*****************************************************************************
 * Copyright (C) 2024 MulticoreWare, Inc
 *
 * Authors: Changsheng Wu <wu.changsheng@sanechips.com.cn>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02111, USA.
 *
 * This program is also available under a commercial proprietary license.
 * For more information, contact us at license @ x265.com.
 *****************************************************************************/

#ifndef X265_COMMON_RISCV64_INTRINSIC_SETUP_H
#define X265_COMMON_RISCV64_INTRINSIC_SETUP_H

#include "primitives.h"

namespace X265_NS {

void setupPixelPrimitives_rvv(EncoderPrimitives &p);
void setupSaoPrimitives_rvv(EncoderPrimitives &p);
void setupFilterPrimitives_rvv(EncoderPrimitives &p);
void setupIntraPrimitives_rvv(EncoderPrimitives &p);

}

#endif // X265_COMMON_RISCV64_INTRINSIC_SETUP_H
